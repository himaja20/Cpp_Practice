

struct stats{

    long long maps;
    long long unmaps;
    long long ins;
    long long outs;
    long long zeros;

};
